## 1.0.0（2021-11-19）
- 优化 组件UI，并提供设计资源，详见:[https://uniapp.dcloud.io/component/uniui/resource](https://uniapp.dcloud.io/component/uniui/resource)
- 文档迁移，详见:[https://uniapp.dcloud.io/component/uniui/uni-link](https://uniapp.dcloud.io/component/uniui/uni-link)
## 1.1.7（2021-11-08）
## 0.0.7（2021-09-03）
- 修复 在 nvue 下不显示的 bug
## 0.0.6（2021-07-30）
- 新增 支持自定义插槽
## 0.0.5（2021-06-21）
- 新增 download 属性，H5平台下载文件名
## 0.0.4（2021-05-12）
- 新增 组件示例地址
## 0.0.3（2021-03-09）
- 新增 href 属性支持 tel:|mailto:

## 0.0.2（2021-02-05）
- 调整为uni_modules目录规范
