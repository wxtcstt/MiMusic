import App from './App'
// #ifndef VUE3
import Vue from 'vue'
Vue.config.productionTip = false
//Vue.prototype.baseMusicUrl = 'http://10.136.119.38:15005/'
Vue.prototype.baseMusicUrl = 'http://192.168.0.222:15005/'
App.mpType = 'app'
const app = new Vue({
  ...App
})

app.$mount()
// #endif

