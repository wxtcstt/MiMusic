<script>
	import {
		mapActions,
		mapMutations
	} from 'vuex'
	import config from '@/admin.config.js'

	export default {
		created() {
			this.clear = undefined
		},
		methods: {
			
		},
		onPageNotFound(msg) {
			uni.redirectTo({
				url: config.error.url
			})
		},
		onLaunch: function() {
			
		},
		onShow: function() {
			console.log('App Show')
			
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style lang="scss">
	@import '@/common/uni.css';
	@import '@/common/uni-icons.css';
	@import '@/common/admin-icons.css';
	@import '@/common/theme.scss';
</style>
