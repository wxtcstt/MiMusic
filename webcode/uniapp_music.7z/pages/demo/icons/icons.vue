<template>
	<view>
		123123
	</view>
</template>

<script>
	
	// 导出默认模块
	export default {
		// 数据属性
		data() {
			return {
				// 数据属性：icons
				
			}
		},


		// 方法
		methods: {
			
		}
	}
</script>


<style lang="scss">
	/* #ifndef H5 */
	page {
		padding-top: 85px;
	}
	/* #endif */
	.icons {
		display: flex;
		flex-direction: row;
		flex-wrap: wrap;
	}

	.icon-item {
		display: flex;
		width: 16.6%;
		height: 120px;
		font-size: 30px;
		text-align: center;
		justify-content: center;
		align-items: center;
		flex-direction: column;
	}

	.icon-item:hover,
	.icon-item:hover .icon-text {
		color: $uni-color-primary;
	}

	.icon-text {
		color: #99a9bf;
		font-size: 12px;
		text-align: center;
		height: 1em;
		line-height: 1em;
		margin-top: 15px;
	}

	/* #ifdef H5 */
	@media only screen and (max-width: 500px) {
		.icon-item {
			width: 33.3%;
		}
	}
	/* #endif */
</style>
