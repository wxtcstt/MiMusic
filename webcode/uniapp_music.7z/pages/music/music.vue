<template>
	<view>
		<view class="uni-header">
			<view class="uni-group hide-on-phone">
				<view class="uni-title">歌曲列表</view>
			</view>
			<view class="uni-group">
				<!-- 输入框 -->
				<input class="uni-search" type="text" v-model="searchVal" @confirm="search" placeholder="输入" />
				<!-- 搜索按钮 -->
				<button class="uni-button" type="default" size="mini" @click="search">搜索</button>
				<!-- 添加按钮 -->
				<button class="uni-button" type="primary" size="mini" @click="addmusic">添加</button>
		
			</view>
		</view>
		<view class="uni-container">
			<!-- 表格组件 -->
			<uni-table :loading="loading" border stripe type="selection"  @selection-change="selectionChange">
				<uni-tr>
					<!-- 表头列 -->
					<uni-th width="150" align="center">歌名</uni-th>
					<uni-th width="150" align="center">作者</uni-th>
					<!-- <uni-th width="150" align="center">时长</uni-th> -->
					<uni-th width="204" align="center">设置</uni-th>
				</uni-tr>
				<uni-tr v-for="(item ,index) in tableData" :key="index">
					<!-- 表格数据列 -->
					<uni-td>{{item.musicname}}</uni-td>
					<uni-td>
						<view class="name">{{item.author}}</view>
					</uni-td>
					<!-- <uni-td>{{item.duration}}</uni-td> -->
					
					<uni-td>
						<view class="uni-group">
							<!-- 删除按钮 -->
							<button class="uni-button" size="mini" type="primary"  @click="playMusic(item.author,item.musicname)">播放</button>
							<button class="uni-button" size="mini" type="warn" @click="deleteMusic(item.author,item.musicname)">删除</button>
						</view>
					</uni-td>
				</uni-tr>
			</uni-table>
			<view class="uni-pagination-box">
				<!-- 分页组件 -->
				<uni-pagination show-icon :page-size="pageSize" :current="pageCurrent" :total="total" @change="change" />
			</view>
		</view>
		<uni-popup ref="addmusicPopup" type="center">
			<view class="modal">
				<scroll-view class="modal-content" scroll-y="true" >
					<view style="background-color: beige;">
						<button  class="add-btn"  @click="uploadFile" >上传</button>
					</view> 
				</scroll-view>
			</view>
		</uni-popup>
	</view>
	
</template>
<script>
	// 导出默认模块
	export default {
		// 数据属性
		data() {
			return {
				// 搜索值
				searchVal: '',
				// 表格数据
				tableData: [{"musicname":"如愿","author":"王菲","duration":10},{"musicname":"像我这样的人","author":"毛不易","duration":10}],
				// 每页数据量
				pageSize: 20,
				// 当前页
				pageCurrent: 1,
				// 数据总量
				total: 0,
				// 加载状态
				loading: false,
				uploadfilename:""
			}
		},

		// 页面加载时的处理函数
		onLoad() {
			// 重置选中项数组
			this.selectedIndexs = []
			// 获取第一页数据
			this.musicNumber()
			this.getData(this.pageCurrent-1)
		},

		// 方法
		methods: {
			// 多选处理
			selectedItems() {
				return this.selectedIndexs.map(i => this.tableData[i])
			},

			// 多选事件处理函数
			selectionChange(e) {
				this.selectedIndexs = e.detail.index
			},

			
			addmusic(){
				this.$refs.addmusicPopup.open()
			},
			// 分页触发事件处理函数
			change(e) {
				this.getData(e.current-1)
			},
			playMusic(author,musicname)
			{
				let that=this
				//请求网络服务
				uni.request({
				  url: this.baseMusicUrl+"playMusic?"+"author="+author+"&musicname="+musicname,
				  method: 'GET', // 请求方法，可选值：GET、POST、PUT、DELETE，默认为GET
				  success: function(res) {
					  if(res.statusCode==200){
						  if(res.data.toString()==="-1")
						  {
							  uni.showToast({
							    title:'失败',
							    icon:'none'
							  })
						  }
						  else
						  { 
							  uni.showToast({
							    title:'成功',
							    icon:'none'
							  })
						  }
					  } 
				  },
				  fail: function(err) {
					console.log("###:",err); 
				  }
				});
			},
            deleteMusic(author,musicname)
			{
				
				let that=this
				//请求网络服务
				uni.request({
				  url: this.baseMusicUrl+"deleteMusic?"+"author="+author+"&musicname="+musicname,
				  method: 'GET', // 请求方法，可选值：GET、POST、PUT、DELETE，默认为GET
				  success: function(res) {
					  if(res.statusCode==200){
						  if(res.data.toString()==="-1")
						  {
							  uni.showToast({
							    title:'失败',
							    icon:'none'
							  })
						  }
						  else
						  { 
							  uni.showToast({
							    title:'删除成功',
							    icon:'none'
							  })
							  console.log("@@:",res.data); // 请求成功后的处理
							  that.tableData=res.data
						  }
					  } 
					that.loading =  false;  
				  },
				  fail: function(err) {
					console.log("###:",err); // 请求失败后的处理
					that.loading =  false;
				  }
				});
			},
			// 搜索函数
			search() {
				if(this.searchVal==="")
				{
					this.getData(0)
				}
				else
				{
					this.loading = true
					let that=this
					//请求网络服务
					uni.request({
					  url: this.baseMusicUrl+"searchMusic?"+"info="+this.searchVal,
					  method: 'GET', // 请求方法，可选值：GET、POST、PUT、DELETE，默认为GET
					  success: function(res) {
						  if(res.statusCode==200){
							  console.log("@@:",res.data); // 请求成功后的处理
							  that.tableData=res.data
						  } 
						that.loading =  false;  
					  },
					  fail: function(err) {
						console.log("###:",err); // 请求失败后的处理
						that.loading =  false;
					  }
					});
				}
				
				
			},
            musicNumber()
			{   
				let that=this
				uni.request({
				  url: this.baseMusicUrl+"musicNumber",
				  method: 'GET', 
				  success: function(res) {
					  if(res.statusCode==200){ 
						  that.total=Number(res.data)
					  } 
				  },
				  fail: function(err) {
					console.log("###:",err); // 请求失败后的处理
					
				  }
				});
			},
			// 获取数据函数 value是用来过滤的
			getData(pageCurrent, value = "") {
				this.loading = true
				let that=this
				//请求网络服务
				uni.request({
				  url: this.baseMusicUrl+"allmusics?"+"pageCurrent="+pageCurrent+"&pageSize="+that.pageSize,
				  method: 'GET', // 请求方法，可选值：GET、POST、PUT、DELETE，默认为GET
				  success: function(res) {
					  if(res.statusCode==200){
						  console.log("@@:",res.data); // 请求成功后的处理
						  that.tableData=res.data
					  } 
					that.loading =  false;  
				  },
				  fail: function(err) {
					console.log("###:",err); // 请求失败后的处理
					that.loading =  false;
				  }
				});
				
			},

          uploadFile() {
            let that=this
            uni.chooseImage({
          	extension:["wav","mp3","flac"],
            	success: (chooseImageRes) => {
            		const tempFilePaths = chooseImageRes.tempFilePaths;
          		    const selectedFileName = chooseImageRes.tempFiles[0].name;
          		
					if (selectedFileName.endsWith(".wav") || selectedFileName.endsWith(".mp3") || selectedFileName.endsWith(".flac")) {
					  uni.uploadFile({
						url: this.baseMusicUrl+"upload", 
						filePath: tempFilePaths[0],
						name: 'file',
						formData: {
							'filename':selectedFileName
						},
						success: (uploadFileRes) => {
						    if(uploadFileRes.statusCode==200 && uploadFileRes.data!="-1")
							{   
								that.tableData.unshift(JSON.parse(uploadFileRes.data))
								console.log("￥￥",that.tableData)
								uni.showToast({
									title: "上传成功",
									icon: 'none'
								});
							}
							else
							{
								uni.showToast({
								  title:'上传失败',
								  icon:'none'
								})
							}
						}
					  });
          		} else {
          		  uni.showToast({
          			  title:'文件格式错误',
          			  icon:'none'
          		  })
          		}
            		
            	}
            });
          	  
            
            
           
          },
		 
			// 伪request请求函数
			request(options) {
				const {
					pageSize,
					pageCurrent,
					success,
					value
				} = options

				let total = tableData.length

				let data = tableData.filter((item, index) => {
					const idx = index - (pageCurrent - 1) * pageSize
					return idx < pageSize && idx >= 0
				})

				if (value) {
					data = []
					tableData.forEach(item => {
						if (item.name.indexOf(value) !== -1) {
							data.push(item)
						}
					})
					total = data.length
				}

				setTimeout(() => {
					typeof success === 'function' && success({
						data: data,
						total: total
					})
				}, 500)
			}
		}
	}
</script>


<style>
	page {
		padding: 0px;
	},
     .uni-app--showleftwindow
	 {
		 	padding: 0px;
	 },
	uni-page-wrapper 
	{
		padding: 0px;
	}

</style>
